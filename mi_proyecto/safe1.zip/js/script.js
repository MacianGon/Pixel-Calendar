document.addEventListener('DOMContentLoaded', function() {
    const registroForm = document.getElementById('registro-form');
    const loginForm = document.getElementById('login-form');
    const mostrarLoginLink = document.getElementById('mostrar-login');
    const mostrarRegistroLink = document.getElementById('mostrar-registro');
    const registroMensaje = document.getElementById('registro-mensaje');
    const loginMensaje = document.getElementById('login-mensaje');
    const authContainer = document.getElementById('auth-container');
    const calendarioContenido = document.querySelector('.contenido-libro');

    let usuarioId = null;

    // Ocultar el contenido del calendario al inicio
    calendarioContenido.style.display = 'none';

    // Mostrar formulario de inicio de sesión
    mostrarLoginLink.addEventListener('click', function(e) {
        e.preventDefault();
        registroForm.style.display = 'none';
        loginForm.style.display = 'block';
        registroMensaje.textContent = ''; // Limpiar mensajes
    });

    // Mostrar formulario de registro
    mostrarRegistroLink.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.style.display = 'none';
        registroForm.style.display = 'block';
        loginMensaje.textContent = ''; // Limpiar mensajes
    });

    // Función para mostrar el calendario
    function mostrarCalendario() {
        authContainer.style.display = 'none';
        calendarioContenido.style.display = 'flex';
        iniciarCalendario(); // Asegúrate de que esta función esté definida y funcione
    }

    // Manejar el envío del formulario de registro
    registroForm.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('Evento submit del formulario de registro detectado.'); // LOG
        const formData = new FormData(registroForm);
        console.log('Datos del formulario de registro:', Object.fromEntries(formData)); // LOG

        fetch('php/registro.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            console.log('Respuesta del servidor (registro) recibida:', response); // LOG
            return response.json();
        })
        .then(data => {
            console.log('Datos JSON de la respuesta (registro):', data); // LOG
            registroMensaje.textContent = data.error || data.success;
            registroMensaje.className = data.error ? '' : 'success';
            if (data.success) {
                registroForm.reset();
                loginForm.style.display = 'block';
                registroForm.style.display = 'none';
            }
        })
        .catch(error => {
            console.error('Error en la petición de registro (Error de red):', error); // LOG
            registroMensaje.textContent = 'Error de red al registrar.';
            registroMensaje.className = '';
        });
    });

    // Manejar el envío del formulario de inicio de sesión
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('Evento submit del formulario de inicio de sesión detectado.'); // LOG
        const formData = new FormData(loginForm);
        console.log('Datos del formulario de inicio de sesión:', Object.fromEntries(formData)); // LOG

        fetch('php/login.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            console.log('Respuesta del servidor (login) recibida:', response); // LOG
            return response.json();
        })
        .then(data => {
            console.log('Datos JSON de la respuesta (login):', data); // LOG
            if (data.success && data.usuario_id) {
                usuarioId = data.usuario_id;
                mostrarCalendario(); // Llama directamente a mostrarCalendario si el inicio de sesión es exitoso
                loginForm.reset();
            } else if (data.error) {
                const loginMensaje = document.getElementById('login-mensaje');
                if (loginMensaje) {
                    loginMensaje.textContent = data.error;
                    loginMensaje.className = '';
                } else {
                    console.error("Error al iniciar sesión:", data.error); // LOG
                }
            } else {
                console.error("Respuesta inesperada del servidor al iniciar sesión:", data); // LOG
            }
        })
        .catch(error => {
            console.error('Error en la petición de inicio de sesión (Error de red):', error); // LOG
            const loginMensaje = document.getElementById('login-mensaje');
            if (loginMensaje) {
                loginMensaje.textContent = 'Error de red al iniciar sesión.';
                loginMensaje.className = '';
            }
        });
    });

    // Función para inicializar el calendario (asegúrate de que tu lógica del calendario esté aquí)
    function iniciarCalendario() {
        const anoElement = document.getElementById('cabecera-ano');
        const mesElement = document.getElementById('mes');
        const fechasElement = document.querySelector('.fechas');
        const nombresMeses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
        let fechaActual = new Date();
        let mesActual = fechaActual.getMonth();
        let anoActual = fechaActual.getFullYear();

        if (anoElement) anoElement.textContent = anoActual;
        if (mesElement) mesElement.textContent = nombresMeses[mesActual];
        if (fechasElement) {
            fechasElement.innerHTML = '';
            let primerDiaSemana = new Date(anoActual, mesActual, 1).getDay();
            let ultimoDiaMes = new Date(anoActual, mesActual + 1, 0).getDate();
            for (let i = 0; i < primerDiaSemana; i++) {
                const diaVacio = document.createElement('div');
                fechasElement.appendChild(diaVacio);
            }
            for (let i = 1; i <= ultimoDiaMes; i++) {
                const diaDiv = document.createElement('div');
                diaDiv.textContent = i;
                fechasElement.appendChild(diaDiv);
            }
        }
        // Aquí puedes añadir la lógica para cargar las notas, etc., si es necesario al inicio.
    }

    // Verificar sesión activa al cargar la página (opcional)
    fetch('php/sesion_activa.php')
    .then(response => response.json())
    .then(data => {
        if (data.usuario_id) {
            usuarioId = data.usuario_id;
            mostrarCalendario();
        }
    })
    .catch(error => {
        console.error('Error al verificar la sesión:', error); // LOG
    });
});