<?php
// php/sesion_activa.php
session_start();
if (isset($_SESSION['usuario_id'])) {
    echo json_encode(array("usuario_id" => $_SESSION['usuario_id']));
} else {
    echo json_encode(array()); // No hay sesión activa
}
?>