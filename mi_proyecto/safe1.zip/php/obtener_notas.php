<?php
require_once 'conexion.php';
session_start();

if (isset($_SESSION["usuario_id"])) {
    $usuario_id = $_SESSION["usuario_id"];
    $mes = $_GET["mes"]; // Recibir el mes (0-11)
    $ano = $_GET["ano"]; // Recibir el año

    // Calcular el primer y último día del mes
    $primer_dia = date('Y-m-d', mktime(0, 0, 0, $mes + 1, 1, $ano));
    $ultimo_dia = date('Y-m-d', mktime(0, 0, 0, $mes + 2, 0, $ano));

    $stmt = $conn->prepare("SELECT fecha, contenido FROM notas WHERE id_usuario = ? AND fecha >= ? AND fecha <= ?");
    $stmt->bind_param("iss", $usuario_id, $primer_dia, $ultimo_dia);
    $stmt->execute();
    $result = $stmt->get_result();

    $notas = [];
    while ($row = $result->fetch_assoc()) {
        $notas[$row["fecha"]] = $row["contenido"];
    }

    echo json_encode($notas);

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Usuario no autenticado."]);
}
?>