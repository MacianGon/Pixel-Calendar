<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pixel-calendar-DB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['tipo' => 'error', 'mensaje' => 'Error de conexión a la base de datos: ' . $conn->connect_error]));
}

$usuario_id = $_GET["usuario_id"] ?? null;
$fecha = $_GET["fecha"] ?? null;

if (empty($usuario_id) || empty($fecha)) {
    echo json_encode(['tipo' => 'error', 'mensaje' => 'Faltan datos para cargar la nota.']);
    $conn->close();
    exit();
}

$stmt = $conn->prepare("SELECT nota FROM notas WHERE usuario_id = ? AND fecha = ?");
$stmt->bind_param("is", $usuario_id, $fecha);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(['tipo' => 'success', 'nota' => $row["nota"]]);
} else {
    echo json_encode(['tipo' => 'success', 'nota' => '']); // No hay nota para este día
}

$stmt->close();
$conn->close();
?>