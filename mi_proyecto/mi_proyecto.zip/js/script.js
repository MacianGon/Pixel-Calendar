document.addEventListener('DOMContentLoaded', function() {
    const registroForm = document.getElementById('registro-form');
    const loginForm = document.getElementById('login-form');
    const mostrarLoginLink = document.getElementById('mostrar-login');
    const mostrarRegistroLink = document.getElementById('mostrar-registro');
    const registroMensaje = document.getElementById('registro-mensaje');
    const loginMensaje = document.getElementById('login-mensaje');
    const authContainer = document.getElementById('auth-container');
    const calendarioContenido = document.querySelector('.contenido-libro');
    const areaNotas = document.getElementById('area-notas');
    const guardarNotaBtn = document.getElementById('guardar-nota-btn');
    const mostrarFechaTitulo = document.getElementById('mostrar-fecha');
    const mensajeNotaDiv = document.getElementById('mensaje-nota');

    let usuarioId = null;
    let fechaSeleccionada = new Date();

    function formatearFecha(date) {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function verificarSesion() {
        fetch('php/verificar_sesion.php')
        .then(response => response.json())
        .then(data => {
            if (data.usuario_id) {
                usuarioId = data.usuario_id;
                mostrarCalendario();
            } else {
                authContainer.style.display = 'block';
                calendarioContenido.style.display = 'none';
            }
        })
        .catch(error => {
            console.error('Error al verificar la sesión:', error);
            authContainer.style.display = 'block';
            calendarioContenido.style.display = 'none';
        });
    }

    function mostrarCalendario() {
        authContainer.style.display = 'none';
        calendarioContenido.style.display = 'flex';
        iniciarCalendario();
        cargarNota(formatearFecha(fechaSeleccionada));
    }

    function cargarNota(fecha) {
        if (!usuarioId) {
            console.warn('Usuario no identificado, no se pueden cargar notas.');
            return;
        }
        fetch(`php/cargar_notas.php?usuario_id=${usuarioId}&fecha=${fecha}`)
        .then(response => response.json())
        .then(data => {
            if (data.tipo === 'success' && data.nota) {
                areaNotas.value = data.nota;
            } else {
                areaNotas.value = '';
            }
            mostrarFechaTitulo.textContent = new Date(fecha).toLocaleDateString();
        })
        .catch(error => {
            console.error('Error al cargar la nota:', error);
            mensajeNotaDiv.textContent = 'Error al cargar la nota.';
            mensajeNotaDiv.className = 'error';
        });
    }

    function guardarNota() {
        if (!usuarioId) {
            console.warn('Usuario no identificado, no se pueden guardar notas.');
            return;
        }
        const nota = areaNotas.value;
        const fecha = formatearFecha(fechaSeleccionada);

        fetch('php/guardar_nota.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `usuario_id=${usuarioId}&fecha=${fecha}&nota=${nota}`
        })
        .then(response => response.json())
        .then(data => {
            mensajeNotaDiv.textContent = data.mensaje;
            mensajeNotaDiv.className = data.tipo;
        })
        .catch(error => {
            mensajeNotaDiv.textContent = 'Error de red al guardar la nota.';
            mensajeNotaDiv.className = 'error';
            console.error('Error:', error);
        });
    }

    areaNotas.addEventListener('blur', guardarNota);
    guardarNotaBtn.addEventListener('click', guardarNota);

    registroForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(registroForm);

        fetch('php/registro.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            registroMensaje.textContent = data.mensaje;
            registroMensaje.className = data.tipo;
            if (data.tipo === 'success') {
                const loginData = new FormData();
                loginData.append('nombre_usuario', registroForm.elements.nombre_usuario.value);
                loginData.append('contrasena', registroForm.elements.contrasena.value);

                fetch('php/login.php', {
                    method: 'POST',
                    body: loginData
                })
                .then(response => response.json())
                .then(loginData => {
                    if (loginData.tipo === 'success' && loginData.usuario_id) {
                        usuarioId = loginData.usuario_id;
                        mostrarCalendario();
                        registroForm.style.display = 'none';
                        authContainer.style.display = 'none';
                    } else {
                        registroMensaje.textContent = 'Registro exitoso. Por favor, inicia sesión.';
                        loginForm.style.display = 'block';
                        registroForm.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Error al intentar iniciar sesión tras el registro:', error);
                    registroMensaje.textContent = 'Registro exitoso, pero hubo un error al iniciar sesión.';
                    loginForm.style.display = 'block';
                    registroForm.style.display = 'none';
                });
            }
        })
        .catch(error => {
            registroMensaje.textContent = 'Error de red al registrar.';
            registroMensaje.className = 'error';
            console.error('Error:', error);
        });
    });

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(loginForm);

        fetch('php/login.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.tipo === 'success' && data.usuario_id) {
                usuarioId = data.usuario_id;
                mostrarCalendario();
                loginForm.style.display = 'none';
                authContainer.style.display = 'none';
            } else {
                loginMensaje.textContent = data.mensaje;
                loginMensaje.className = data.tipo;
            }
        })
        .catch(error => {
            loginMensaje.textContent = 'Error de red al iniciar sesión.';
            loginMensaje.className = 'error';
            console.error('Error:', error);
        });
    });

    mostrarLoginLink.addEventListener('click', function(e) {
        e.preventDefault();
        registroForm.style.display = 'none';
        loginForm.style.display = 'block';
        registroMensaje.textContent = '';
        loginMensaje.textContent = '';
    });

    mostrarRegistroLink.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.style.display = 'none';
        registroForm.style.display = 'block';
        registroMensaje.textContent = '';
        loginMensaje.textContent = '';
    });

    const anoElement = document.getElementById('cabecera-ano');
    const mesElement = document.getElementById('mes');
    const fechasElement = document.querySelector('.fechas');
    const nombresMeses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    let fechaActualCalendario = new Date();
    let mesActualCalendario = fechaActualCalendario.getMonth();
    let anoActualCalendario = fechaActualCalendario.getFullYear();

    function iniciarCalendario() {
        anoElement.textContent = anoActualCalendario;
        mesElement.textContent = nombresMeses[mesActualCalendario];
        generarCalendario(anoActualCalendario, mesActualCalendario);
    }

    function generarCalendario(ano, mes) {
        fechasElement.innerHTML = '';
        const primerDiaSemana = new Date(ano, mes, 1).getDay();
        const ultimoDiaMes = new Date(ano, mes + 1, 0).getDate();

        for (let i = 0; i < primerDiaSemana; i++) {
            const diaVacio = document.createElement('div');
            fechasElement.appendChild(diaVacio);
        }

        for (let i = 1; i <= ultimoDiaMes; i++) {
            const diaDiv = document.createElement('div');
            diaDiv.textContent = i;
            diaDiv.addEventListener('click', function() {
                const nuevaFecha = new Date(ano, mes, i);
                fechaSeleccionada = nuevaFecha;
                cargarNota(formatearFecha(nuevaFecha));
                document.querySelectorAll('.fechas div').forEach(div => div.classList.remove('seleccionado'));
                diaDiv.classList.add('seleccionado');
            });

            const hoy = new Date();
            if (ano === hoy.getFullYear() && mes === hoy.getMonth() && i === hoy.getDate()) {
                diaDiv.classList.add('hoy');
            }

            fechasElement.appendChild(diaDiv);
        }
    }

    document.getElementById('prev-mes').addEventListener('click', function() {
        mesActualCalendario--;
        if (mesActualCalendario < 0) {
            mesActualCalendario = 11;
            anoActualCalendario--;
        }
        iniciarCalendario();
    });

    document.getElementById('next-mes').addEventListener('click', function() {
        mesActualCalendario++;
        if (mesActualCalendario > 11) {
            mesActualCalendario = 0;
            anoActualCalendario++;
        }
        iniciarCalendario();
    });

    verificarSesion();
});