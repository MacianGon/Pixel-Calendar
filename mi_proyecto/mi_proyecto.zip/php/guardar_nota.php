<?php
header('Content-Type: application/json');
require 'conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['tipo' => 'error', 'mensaje' => 'No estás autenticado.']);
        $conn->close();
        exit();
    }

    $usuario_id = $_SESSION['usuario_id'];
    $fecha = $_POST["fecha"];
    $nota = $_POST["nota"];

    if (empty($fecha)) {
        echo json_encode(['tipo' => 'error', 'mensaje' => 'La fecha es obligatoria.']);
        $conn->close();
        exit();
    }

    // Verificar si ya existe una nota para este usuario y fecha
    $stmt_check = $conn->prepare("SELECT id FROM notas WHERE usuario_id = ? AND fecha = ?");
    $stmt_check->bind_param("is", $usuario_id, $fecha);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        // Actualizar la nota existente
        $stmt_update = $conn->prepare("UPDATE notas SET nota = ? WHERE usuario_id = ? AND fecha = ?");
        $stmt_update->bind_param("sis", $nota, $usuario_id, $fecha);

        if ($stmt_update->execute()) {
            echo json_encode(['tipo' => 'success', 'mensaje' => 'Nota actualizada.']);
        } else {
            echo json_encode(['tipo' => 'error', 'mensaje' => 'Error al actualizar la nota: ' . $stmt_update->error]);
        }
        $stmt_update->close();
    } else {
        // Insertar una nueva nota
        $stmt_insert = $conn->prepare("INSERT INTO notas (usuario_id, fecha, nota) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("iss", $usuario_id, $fecha, $nota);

        if ($stmt_insert->execute()) {
            echo json_encode(['tipo' => 'success', 'mensaje' => 'Nota guardada.']);
        } else {
            echo json_encode(['tipo' => 'error', 'mensaje' => 'Error al guardar la nota: ' . $stmt_insert->error]);
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
} else {
    echo json_encode(['tipo' => 'error', 'mensaje' => 'Método no permitido.']);
}

$conn->close();
?>